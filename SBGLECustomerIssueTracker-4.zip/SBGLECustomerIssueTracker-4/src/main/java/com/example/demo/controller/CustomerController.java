package com.example.demo.controller;
import java.awt.List;
import java.sql.Date;
import java.util.ArrayList;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;


import com.example.demo.exception.ApplicationException;
import com.example.demo.model.CCRepresentative;
import com.example.demo.model.Customer;
import com.example.demo.model.IssueDetail;
import com.example.demo.service.CustomerIssueService;





@Controller
public class  CustomerController

{
	
	@Autowired
	CustomerIssueService custService;
	
	@Autowired 
	  public CustomerController(CustomerIssueService service, Validator validator) {
	  System.out.println("in parametized constr of controller with validator");
	  this.custService=service; this.validator=validator; }
	int issueId=9;
	String issueStatus1="InProgress";
	String curIssueId1="";
	
	@Autowired
	private Validator validator;
	


	@GetMapping("/login1")
		public String showLoginPage(@ModelAttribute("customer") Customer customer )
	{
	
		return "login";
	}
	
	@RequestMapping("/login")
	public String showCustomerPage(@Valid @ModelAttribute("customer") Customer customer,BindingResult result)	
		
	{
		if(result.hasErrors())
		{
			return "login";
		}
		else
		{
			//System.out.println(customer.getCustomerId());
			custService.addCustomerObject(customer);
			return "customerform";
		}
	}
	
	@GetMapping("/customerform")
	public String showCustomerForm() {
		return "customerform";
	}
	
	@RequestMapping("/get1")
	public String showCustomerIssue( @RequestParam String issueid,  String option,Model m) throws ApplicationException
	{

		
		//Type Your Code here
		if(option.equals("raise"))
		{
			issueId=issueId+1;
			String curIssueId1="I"+issueId;
			m.addAttribute("curIssueId1",curIssueId1);
			return "raiseissue";
		}
		else
		{
			IssueDetail	issue=custService.getIssueDetailById(issueid);
			if(issueid.equalsIgnoreCase(issue.getCustIssueId()))
			{

				m.addAttribute("CustIssueId",issue.getCustIssueId());
				m.addAttribute("IssueReportDate", issue.getIssueReportDate());
				m.addAttribute("CustId",issue.getCustId());
				m.addAttribute("Category", issue.getCategory());
				m.addAttribute("Description",issue.getDescription());
				m.addAttribute("IssueStatus", issue.getIssueStatus());
				m.addAttribute("CcRepId",issue.getCcRepId());
				
				return "customerissue";
			}
			else
			{
				throw new ApplicationException("No Record found with that id");
			}
		}

	}


	@RequestMapping("/get2")
	public String raiseIssue(Model m
			,  @RequestParam ("issueReportDate") String issueReportDate
			,@RequestParam ("customerId") String customerId 
			, @RequestParam ("category") String category 
			,@RequestParam ("descr") String descr) throws ApplicationException
	{
		
					String curIssueId2="I"+issueId;
					String avaliableCCR=custService.getAvailableCCR();
					System.out.println(avaliableCCR);
					
					if(issueReportDate.trim().isEmpty()||customerId.trim().isEmpty()||category.trim().isEmpty()||descr.trim().isEmpty())
					{
						throw new ApplicationException("Please Entre The Valid Details");
					}
					if(!custService.validateDateOfReport(issueReportDate))
					{
						throw new ApplicationException("Please Enter Valid Date Format (yyyy-mm-dd)");
						
					}
					
					
				custService.issuesList.add(new IssueDetail(curIssueId2,custService.stringToDateConverter(issueReportDate),customerId,category,descr,issueStatus1,avaliableCCR));
				CCRepresentative ccrIssues=custService.getCCRById(avaliableCCR);
				ccrIssues.setIssuesInProgress(ccrIssues.getIssuesInProgress()+1);
				m.addAttribute("curIssueId2",curIssueId2);
				m.addAttribute("issueReportDate", issueReportDate);
				m.addAttribute("custId", customerId);
				m.addAttribute("category",category);
				m.addAttribute("descr",descr);
				m.addAttribute("issueStatus",issueStatus1);
				m.addAttribute("avaliableCCR",avaliableCCR);
				
				
				return "issueraised";

			}
		
	}

	

