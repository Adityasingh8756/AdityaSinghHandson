package com.example.demo.model;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;


public class Customer {

	
@NotBlank(message="Customer Id is Required")
  private String customerId;

@NotBlank(message="Customer Name Is Required")
  private String customerName;

	@NotBlank(message="Customer Address Is Required")
  private String customerAddress;
	
	//@NotBlank(message="moble number should be 10 digits and started with digit 7 , 8 and 9")
	@Pattern(regexp="[7-9][]0-9]{9}",message="moble number should be 10 digits and started with digit 7 , 8 and 9")
  private String customerNumber;
  
@Email(message="Enter The Valid EmailId")
  private String loginId;
@NotBlank(message="Password is Required")
  private String password;

public String getCustomerId() {
	return customerId;
}

public void setCustomerId(String customerId) {
	this.customerId = customerId;
}

public String getCustomerName() {
	return customerName;
}

public void setCustomerName(String customerName) {
	this.customerName = customerName;
}

public String getCustomerAddress() {
	return customerAddress;
}

public void setCustomerAddress(String customerAddress) {
	this.customerAddress = customerAddress;
}

public String getCustomerNumber() {
	return customerNumber;
}

public void setCustomerNumber(String customerNumber) {
	this.customerNumber = customerNumber;
}

public String getLoginId() {
	return loginId;
}

public void setLoginId(String loginId) {
	this.loginId = loginId;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
			+ customerAddress + ", customerNumber=" + customerNumber + ", loginId=" + loginId + ", password=" + password
			+ "]";
}
  
  

}