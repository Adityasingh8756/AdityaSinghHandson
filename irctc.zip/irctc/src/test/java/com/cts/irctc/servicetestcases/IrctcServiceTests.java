package com.cts.irctc.servicetestcases;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertTrue;

import org.junit.runner.RunWith;

import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cts.irctc.exception.ApplicationException;
import com.cts.irctc.model.TicketBooking;
import com.cts.irctc.model.TrainInfo;
import com.cts.irctc.service.IrctcService;


public class IrctcServiceTests {
	
	private IrctcService service=null;
	private MockMvc mockMvc;
	
	@BeforeTest
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		service=new IrctcService();
		mockMvc = MockMvcBuilders.standaloneSetup(service).build();
	}
  
	@Test (expectedExceptions = ApplicationException.class, expectedExceptionsMessageRegExp = "From and to city can't be same")
	public void testWhenFromAndToCityIsSame() throws Throwable {
		
		TicketBooking ticketBooking = Mockito.mock(TicketBooking.class);
		when(ticketBooking.getFromCity()).thenReturn("Pune");
		when(ticketBooking.getToCity()).thenReturn("Pune");
	 
		// ApplicationException exception!
	 
			service.getTicketBookingResult(ticketBooking);
			fail("Failed to test exception when from and to city is same");
	}
	
	@Test
	public void testgetPNRNumber1() throws Throwable{
		TicketBooking ticketBooking = Mockito.mock(TicketBooking.class);
		//TrainInfo availableTrain = Mockito.mock(TrainInfo.class);
		
		when(ticketBooking.getFromCity()).thenReturn("Pune");
		when(ticketBooking.getToCity()).thenReturn("Bangalore");
		when(ticketBooking.getTravelClass()).thenReturn("AC First Class (1A)");
		when(ticketBooking.getMobileNumber()).thenReturn("8845678901");
		
		when(service.getPNRNumber(ticketBooking)).thenReturn("010-8845678");
	}
	
	@Test(expectedExceptions = ApplicationException.class, expectedExceptionsMessageRegExp = "From and to city can't be same")
	public void testgetPNRNumber2() throws Throwable{
		TicketBooking ticketBooking = Mockito.mock(TicketBooking.class);
		//TrainInfo availableTrain = Mockito.mock(TrainInfo.class);
		
		when(ticketBooking.getFromCity()).thenReturn("Pune");
		when(ticketBooking.getToCity()).thenReturn("Pune");
		when(ticketBooking.getTravelClass()).thenReturn("AC First Class (1A)");
		when(ticketBooking.getMobileNumber()).thenReturn("8845678901");
		
		service.getPNRNumber(ticketBooking);
		fail("Failed to test exception when from and to city is same");
	}
	
	@Test
	public void testTicketBookingWhenTrainAvailable() throws Throwable{
		
	TicketBooking ticketBooking=new TicketBooking();	
		ticketBooking.setFromCity("Pune");
		ticketBooking.setToCity("Bangalore");
		ticketBooking.setTravelClass("AC First Class (1A)");
		TrainInfo availableTrain=service.getTicketBookingResult(ticketBooking);
		
		if(availableTrain.getTrainNumber().equals("01013")) {
			assertTrue(true);
		}else {
			fail("Failed to get train information for available train");
		}
	}
	
	@Test
	public void testTicketBookingWhenTrainNotAvailable() throws Throwable{
		
	TicketBooking ticketBooking=new TicketBooking();	
		ticketBooking.setFromCity("Chennai");
		ticketBooking.setToCity("Delhi");
		ticketBooking.setTravelClass("AC First Class (1A)");
		TrainInfo availableTrain=service.getTicketBookingResult(ticketBooking);
		
		if(availableTrain.getTrainNumber()==null) {
			assertTrue(true);
		}else {
			fail("Failed to test when train not found");
		}
	}
}
