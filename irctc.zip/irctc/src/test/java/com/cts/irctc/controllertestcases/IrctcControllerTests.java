package com.cts.irctc.controllertestcases;

import static org.junit.Assert.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cts.irctc.controller.IrctcController;
import com.cts.irctc.exception.ApplicationException;
import com.cts.irctc.model.TicketBooking;
import com.cts.irctc.service.IrctcService;

public class IrctcControllerTests {
	private MockMvc mockMvc;
	//@Mock
	IrctcService service=new IrctcService();
	
	IrctcController controller=null;
	
	@BeforeTest
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		controller = new IrctcController(service);
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}	
	
	@Test(priority = 1)	
	  public void testTicketBookinForm() throws Exception {
		MvcResult result=	 mockMvc.perform(get("/showTicketBookingForm")).andReturn();
		int status=result.getResponse().getStatus();
		  if(status!=200) {
			  fail("Failed to load ticketBooking page");
		  }else {
			  mockMvc.perform(get("/showTicketBookingForm"))
				 .andExpect(status().isOk()) 
				 .andExpect(view().name("ticketBooking"));	
		  }		 	  
	  }
	@Test(priority = 2)
	public void testgetTicketBookingResultPageWithTicketDetails() {
		try {
			TicketBooking ticketBooking=new TicketBooking();
			ticketBooking.setFromCity("Pune");
			ticketBooking.setToCity("Bangalore");
			ticketBooking.setTravelClass("AC First Class (1A)");
			ticketBooking.setCustomerName("John");
			ticketBooking.setMobileNumber("8123456789");
			ticketBooking.setNoOfTickets(1);
			
			RequestBuilder request = MockMvcRequestBuilders.post("/getTicketBookingResultPage").flashAttr("ticketBooking", ticketBooking);
			//handle failure senario
			MvcResult result= mockMvc.perform(request).andReturn();
			if(result.getResponse().getStatus()!=200) {
				fail("Failed to get ticketBookingResult page after entering ticket booking details for available train ");
			}else {
				mockMvc.perform(request)
				.andExpect(status().isOk())
				.andExpect(view().name("ticketBookingResult"));			
			}
				
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}//catch
	}//method
	
	
	@Test(priority = 3)
	public void testTrainNotAvailablePage() {
		try {
			TicketBooking ticketBooking=new TicketBooking();
			ticketBooking.setFromCity("Pune");
			ticketBooking.setToCity("Delhi");
			ticketBooking.setTravelClass("AC First Class (1A)");
			ticketBooking.setCustomerName("John");
			ticketBooking.setMobileNumber("8123456789");
			ticketBooking.setNoOfTickets(1);
			
			RequestBuilder request = MockMvcRequestBuilders.post("/getTicketBookingResultPage").flashAttr("ticketBooking", ticketBooking);
			//handle failure senario
			MvcResult result= mockMvc.perform(request).andReturn();
			if(result.getResponse().getStatus()!=200) {
				fail("Failed to get trainNotAvailable page after entering ticket booking details for not available train ");
			}else {
				mockMvc.perform(request)
				.andExpect(status().isOk())
				.andExpect(view().name("trainNotAvailable"));			
			}
				
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}//catch
	}//method
	
	@Test(priority = 4, expectedExceptions = {Exception.class,ApplicationException.class})
	public void testticketBookingWithSameFromAndToCity()throws Exception {
		
			TicketBooking ticketBooking=new TicketBooking();
			ticketBooking.setFromCity("Pune");
			ticketBooking.setToCity("Pune");
			ticketBooking.setTravelClass("AC First Class (1A)");
			ticketBooking.setCustomerName("John");
			ticketBooking.setMobileNumber("8123456789");
			ticketBooking.setNoOfTickets(1);
			
			RequestBuilder request = MockMvcRequestBuilders.post("/getTicketBookingResultPage").flashAttr("ticketBooking", ticketBooking);
			//handle failure senario
			MvcResult result= mockMvc.perform(request).andReturn();
			fail("Failed to throw exception for same from and to city");
		
	}//method
	
	//test binding error
	@Test(priority = 5)
	public void testgetTicketBookingResultPageWithoutTicketDetails() {
		try {
			TicketBooking ticketBooking=new TicketBooking();
						
			RequestBuilder request = MockMvcRequestBuilders.post("/getTicketBookingResultPage").flashAttr("ticketBooking", ticketBooking);
			//handle failure senario
			MvcResult result= mockMvc.perform(request).andReturn();
			if(result.getResponse().getStatus()!=200) {
				fail("Failed to get ticketBooking page for mandatory fields ");
			}else {
				System.out.println("in else of binding error");
				mockMvc.perform(request)
				.andExpect(status().isOk())
				.andExpect(view().name("ticketBooking"));			
			}
				
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}//catch
	}//method
}
